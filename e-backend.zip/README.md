### Category Add Api

##### /category/add
--------------------
### Category Get Api

##### /products/categories
--------------------------

## Product Add Api

##### /product/add
--------------------------
## Product Get Api

##### /products

-------------------------
## Category - Product Show

##### /products/category/{category}
---------------------------

## Product By Id

##### /products/{id}

-------------------------

## Category Update and Delete

##### put('/category/update/{id}')

--------------------------

## Category Edit and Delete

##### put('/category/update/{id}')
##### delete('/category/delete/{id}')
--------------------------

## Product Edit and Delete

##### Route::put('/product/update/{id}')
##### delete('/product/delete/{id}')
--------------------------------------
## Order Add API

##### /order/add
